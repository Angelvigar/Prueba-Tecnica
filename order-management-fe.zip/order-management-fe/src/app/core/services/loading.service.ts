import { Injectable, computed, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class LoadingService {
  /**
   * Usamos un contador (no boolean) para soportar múltiples requests concurrentes.
   * Se expone como `isLoading` para UI.
   */
  private readonly pendingCount = signal(0);

  readonly isLoading = computed(() => this.pendingCount() > 0);

  start(): void {
    this.pendingCount.update((v) => v + 1);
  }

  stop(): void {
    this.pendingCount.update((v) => Math.max(0, v - 1));
  }

  reset(): void {
    this.pendingCount.set(0);
  }
}

