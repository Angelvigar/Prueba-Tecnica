import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';
import { ApiError } from '../../models/api-error.model';
import { ApiConfigService } from './api-config.service';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly config = inject(ApiConfigService);

  get<T>(path: string, params?: Record<string, string | number | boolean | null | undefined>): Observable<T> {
    return this.http
      .get<T>(this.toUrl(path), { params: this.toHttpParams(params) })
      .pipe(catchError((e) => this.mapError(e)));
  }

  post<T>(path: string, body: unknown): Observable<T> {
    return this.http.post<T>(this.toUrl(path), body).pipe(catchError((e) => this.mapError(e)));
  }

  put<T>(path: string, body: unknown): Observable<T> {
    return this.http.put<T>(this.toUrl(path), body).pipe(catchError((e) => this.mapError(e)));
  }

  patch<T>(path: string, body?: unknown): Observable<T> {
    return this.http.patch<T>(this.toUrl(path), body ?? {}).pipe(catchError((e) => this.mapError(e)));
  }

  delete<T>(path: string): Observable<T> {
    return this.http.delete<T>(this.toUrl(path)).pipe(catchError((e) => this.mapError(e)));
  }

  /**
   * Si el path ya es URL absoluta lo respetamos (útil para authUrl).
   */
  private toUrl(path: string): string {
    if (/^https?:\/\//i.test(path)) return path;
    const base = this.config.apiUrl.replace(/\/$/, '');
    const clean = path.startsWith('/') ? path : `/${path}`;
    return `${base}${clean}`;
  }

  private toHttpParams(params?: Record<string, string | number | boolean | null | undefined>): HttpParams | undefined {
    if (!params) return undefined;
    let httpParams = new HttpParams();
    for (const [k, v] of Object.entries(params)) {
      if (v === null || v === undefined || v === '') continue;
      httpParams = httpParams.set(k, String(v));
    }
    return httpParams;
  }

  private mapError(err: unknown): Observable<never> {
    // Normalizamos a un ApiError para consumo consistente en UI.
    if (err instanceof HttpErrorResponse) {
      const apiError: ApiError = {
        code: err.status || 'HTTP_ERROR',
        message:
          (typeof err.error === 'object' && err.error?.message) ||
          err.message ||
          'Ocurrió un error al comunicar con el servidor.',
        detail: err.error
      };
      return throwError(() => apiError);
    }

    return throwError(() => ({
      code: 'UNKNOWN',
      message: 'Ocurrió un error inesperado.',
      detail: err
    } satisfies ApiError));
  }
}

