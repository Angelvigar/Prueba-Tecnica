export interface ApiError {
  /** Código HTTP o código lógico de la API */
  code: number | string;
  /** Mensaje amigable para UI */
  message: string;
  /** Detalle técnico (opcional) */
  detail?: unknown;
}

