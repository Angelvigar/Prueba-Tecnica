import { importProvidersFrom } from '@angular/core';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';

import { authInterceptor } from './auth/interceptors/auth.interceptor';
import { errorInterceptor } from './interceptors/error.interceptor';
import { loadingInterceptor } from './interceptors/loading.interceptor';

export const coreProviders = [
  provideHttpClient(withInterceptors([loadingInterceptor, authInterceptor, errorInterceptor])),
  importProvidersFrom(MatSnackBarModule, MatDialogModule)
];

