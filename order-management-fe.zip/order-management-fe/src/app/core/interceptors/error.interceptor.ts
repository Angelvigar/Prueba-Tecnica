import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../auth/services/auth.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const snack = inject(MatSnackBar);
  const auth = inject(AuthService);

  return next(req).pipe(
    catchError((err: unknown) => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 401) {
          // Token inválido/expirado → cerramos sesión.
          auth.logout();
        }

        const apiMessage =
          (typeof err.error === 'object' && (err.error as any)?.message) ||
          err.message ||
          'Ocurrió un error inesperado.';

        // Mostramos error amigable, evitando spam en endpoints silenciosos.
        if (!req.headers.has('X-Skip-Error')) {
          snack.open(apiMessage, 'Cerrar', { duration: 5000 });
        }
      } else {
        if (!req.headers.has('X-Skip-Error')) {
          snack.open('Ocurrió un error inesperado.', 'Cerrar', { duration: 5000 });
        }
      }

      return throwError(() => err);
    })
  );
};

