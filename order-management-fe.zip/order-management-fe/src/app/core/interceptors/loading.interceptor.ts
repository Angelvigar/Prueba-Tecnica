import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { finalize } from 'rxjs';
import { LoadingService } from '../services/loading.service';

export const loadingInterceptor: HttpInterceptorFn = (req, next) => {
  const loading = inject(LoadingService);

  // Permitimos opt-out por header (útil para polling/background).
  if (req.headers.has('X-Skip-Loading')) {
    const clean = req.clone({ headers: req.headers.delete('X-Skip-Loading') });
    return next(clean);
  }

  loading.start();
  return next(req).pipe(finalize(() => loading.stop()));
};
