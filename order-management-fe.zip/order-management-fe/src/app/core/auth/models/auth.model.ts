export type Role = 'Admin' | 'Gestor' | 'Consultor';

export interface User {
  id?: number | string;
  username: string;
  fullName?: string;
  email?: string;
  roles: Role[];
}

/**
 * Payload típico de JWT (puede variar por backend).
 * Se soportan alias comunes para roles y usuario.
 */
export interface JwtPayload {
  sub?: string;
  name?: string;
  username?: string;
  email?: string;
  roles?: string[]; // custom
  role?: string | string[]; // ms style
  authorities?: string[]; // spring
  exp?: number;
  iat?: number;
  [key: string]: unknown;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

