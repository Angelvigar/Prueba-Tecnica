import { HttpClient } from '@angular/common/http';
import { Injectable, computed, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, map, tap, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { StorageService } from '../../services/storage.service';
import { JwtPayload, LoginRequest, LoginResponse, Role, User } from '../models/auth.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly storage = inject(StorageService);
  private readonly router = inject(Router);

  private readonly userSignal = signal<User | null>(null);
  readonly user = this.userSignal.asReadonly();
  readonly isAuthenticated = computed(() => !!this.userSignal());
  readonly roles = computed(() => this.userSignal()?.roles ?? []);

  constructor() {
    this.hydrateFromStorage();
  }

  login(req: LoginRequest) {
    // Quitamos trailing slash en authUrl para evitar doble "//".
    const url = `${environment.authUrl.replace(/\/$/, '')}/login`;
    return this.http.post<LoginResponse>(url, req).pipe(
      map((res) => res?.token),
      tap((token) => {
        if (!token) throw new Error('Token no recibido.');
        this.setSession(token);
      }),
      map(() => true),
      catchError((err) => {
        const message =
          (typeof err?.error === 'object' && err?.error?.message) ||
          err?.message ||
          'Credenciales inválidas o error de servidor.';
        return throwError(() => new Error(message));
      })
    );
  }

  logout(): void {
    this.storage.remove(environment.tokenKey);
    this.storage.remove(environment.userKey);
    this.userSignal.set(null);
    void this.router.navigateByUrl('/auth/login');
  }

  getToken(): string | null {
    return this.storage.getString(environment.tokenKey);
  }

  hasAnyRole(expected: Role[]): boolean {
    if (!expected.length) return true;
    const current = new Set(this.roles());
    return expected.some((r) => current.has(r));
  }

  private hydrateFromStorage(): void {
    const token = this.getToken();
    if (!token) return;
    try {
      this.setSession(token);
    } catch {
      // Si el token está corrupto/expirado limpiamos.
      this.logout();
    }
  }

  private setSession(token: string): void {
    const payload = this.decodeJwt(token);
    if (payload.exp && Date.now() / 1000 >= payload.exp) {
      throw new Error('Token expirado.');
    }

    const roles = this.extractRoles(payload);
    const username = (payload.username || payload.sub || payload.name || 'user') as string;

    const user: User = {
      username,
      email: payload.email as string | undefined,
      fullName: payload.name as string | undefined,
      roles
    };

    this.storage.setString(environment.tokenKey, token);
    this.storage.set(environment.userKey, user);
    this.userSignal.set(user);
  }

  private extractRoles(payload: JwtPayload): Role[] {
    const raw =
      (Array.isArray(payload.Roles) ? payload.Roles : payload.Roles ? [payload.Roles] : undefined) ??
      payload.roles ??
      (Array.isArray(payload.role) ? payload.role : payload.role ? [payload.role] : undefined) ??
      payload.authorities ??
      [];

    const roles = (raw ?? []).map((r) => String(r));

    // Normalizamos a nuestro enum de roles.
    const allowed: Role[] = ['Admin', 'Gestor', 'Consultor'];
    const normalized = roles
      .map((r) => r.replace(/^ROLE_/, ''))
      .map((r) => (r === 'Manager' ? 'Gestor' : r))
      .filter((r): r is Role => allowed.includes(r as Role));

    return Array.from(new Set(normalized));
  }

  private decodeJwt(token: string): JwtPayload {
    // JWT: header.payload.signature
    const parts = token.split('.');
    if (parts.length < 2) throw new Error('JWT inválido.');

    const base64Url = parts[1];
    const json = this.base64UrlDecode(base64Url);
    return JSON.parse(json) as JwtPayload;
  }

  /**
   * Decodifica base64-url (sin libs externas).
   * Nota: atob() existe en navegador, pero no en SSR; este proyecto es SPA.
   */
  private base64UrlDecode(input: string): string {
    const base64 = input.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), '=');
    return decodeURIComponent(
      Array.prototype.map
        .call(atob(padded), (c: string) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
  }
}

