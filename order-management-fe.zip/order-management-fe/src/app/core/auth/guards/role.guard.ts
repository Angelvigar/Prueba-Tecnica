import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Role } from '../models/auth.model';

/**
 * Guard funcional parametrizable por roles requeridos.
 */
export const roleGuard =
  (expectedRoles: Role[]): CanActivateFn =>
  (_route, _state) => {
    const auth = inject(AuthService);
    const router = inject(Router);

    if (!auth.isAuthenticated()) {
      return router.createUrlTree(['/auth/login']);
    }

    if (auth.hasAnyRole(expectedRoles)) return true;

    // Si no tiene rol, lo redirigimos a dashboard.
    return router.createUrlTree(['/dashboard']);
  };

