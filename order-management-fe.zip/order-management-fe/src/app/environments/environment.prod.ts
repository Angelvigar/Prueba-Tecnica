export const environment = {
  production: true,
  apiUrl: 'https://localhost:7061/api/v1',
  authUrl: 'https://localhost:7024/api/v1/auth',
  tokenKey: 'auth_token',
  userKey: 'user_data'
};
