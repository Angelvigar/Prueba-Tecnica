export const environment = {
  production: false,
  // Port 7061 servicio de pedidos
  apiUrl: 'https://localhost:7061/api/v1',

  // Port 7024 servicio de AUTH
  authUrl: 'https://localhost:7024/api/v1/auth',

  tokenKey: 'auth_token',
  userKey: 'user_data'
};
