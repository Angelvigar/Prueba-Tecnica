export const environment = {
  production: false,
  // Port 7061 es el de tu servicio de PEDIDOS (Orders)
  apiUrl: 'https://localhost:7061/api/v1',

  // Port 7024 es el de tu servicio de AUTH
  authUrl: 'https://localhost:7024/api/v1/auth',

  tokenKey: 'auth_token',
  userKey: 'user_data'
};
