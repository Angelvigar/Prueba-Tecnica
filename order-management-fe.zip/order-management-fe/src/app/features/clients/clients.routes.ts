import { Routes } from '@angular/router';
import { MainLayoutComponent } from '../../shared/layouts/main-layout/main-layout.component';
import { ClientDetailComponent } from './pages/client-detail/client-detail.component';
import { ClientListComponent } from './pages/client-list/client-list.component';

export const CLIENTS_ROUTES: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      { path: '', component: ClientListComponent },
      { path: 'new', component: ClientDetailComponent },
      { path: ':id', component: ClientDetailComponent }
    ]
  }
];

