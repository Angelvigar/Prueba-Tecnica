import { Injectable, computed, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { ClientService } from '../services/client.service';
import { Client, ClientCreate, ClientUpdate } from '../models/client.model';

@Injectable({ providedIn: 'root' })
export class ClientsState {
  private readonly service = inject(ClientService);

  private readonly clientsSignal = signal<Client[]>([]);
  readonly clients = this.clientsSignal.asReadonly();

  private readonly loadingSignal = signal(false);
  readonly loading = this.loadingSignal.asReadonly();

  private readonly errorSignal = signal<string | null>(null);
  readonly error = this.errorSignal.asReadonly();

  readonly activeCount = computed(() => this.clientsSignal().filter((c) => c.active !== false).length);

  loadAll(): void {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    this.service
      .getAll()
      .pipe(finalize(() => this.loadingSignal.set(false)))
      .subscribe({
        next: (items) => this.clientsSignal.set(items ?? []),
        error: (e: unknown) => this.errorSignal.set(e instanceof Error ? e.message : 'No se pudieron cargar clientes.')
      });
  }

  getById(id: number | string) {
    return this.service.getById(id);
  }

  create(payload: ClientCreate) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.create(payload).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  update(id: number | string, payload: ClientUpdate) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.update(id, payload).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  remove(id: number | string) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.delete(id).pipe(finalize(() => this.loadingSignal.set(false)));
  }
}

