export interface Client {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  status?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ClientCreate {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
}

export type ClientUpdate = ClientCreate;
