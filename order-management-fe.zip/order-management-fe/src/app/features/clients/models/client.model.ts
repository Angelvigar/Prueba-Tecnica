export interface Client {
  id: number;
  name: string;
  email: string;
  phone?: string;
  active?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ClientCreate {
  name: string;
  email: string;
  phone?: string;
  active?: boolean;
}

export type ClientUpdate = ClientCreate;

