import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NgIf } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ClientCreate, Client } from '../../models/client.model';

@Component({
  selector: 'app-client-form',
  standalone: true,
  imports: [
    NgIf,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSlideToggleModule
  ],
  templateUrl: './client-form.component.html',
  styleUrl: './client-form.component.scss'
})
export class ClientFormComponent {
  private readonly fb = inject(FormBuilder);

  @Input() set value(v: Client | null | undefined) {
    if (!v) return;
    this.form.patchValue({
      name: v.name,
      email: v.email,
      phone: v.phone ?? '',
      active: v.active !== false
    });
  }

  @Input() saving = false;
  @Output() saveClient = new EventEmitter<ClientCreate>();
  @Output() cancel = new EventEmitter<void>();

  readonly submitted = signal(false);

  readonly form = this.fb.nonNullable.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    email: ['', [Validators.required, Validators.email]],
    phone: [''],
    active: [true]
  });

  submit(): void {
    this.submitted.set(true);
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const { name, email, phone, active } = this.form.getRawValue();
    this.saveClient.emit({ name: name.trim(), email: email.trim(), phone: phone?.trim() || undefined, active });
  }
}
