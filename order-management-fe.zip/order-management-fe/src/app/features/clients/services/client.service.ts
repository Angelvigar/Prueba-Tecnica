import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api/api.service';
import { Client, ClientCreate, ClientUpdate } from '../models/client.model';

@Injectable({ providedIn: 'root' })
export class ClientService {
  private readonly api = inject(ApiService);

  getAll(): Observable<Client[]> {
    return this.api.get<Client[]>('/clients');
  }

  getById(id: number | string): Observable<Client> {
    return this.api.get<Client>(`/clients/${id}`);
  }

  create(payload: ClientCreate): Observable<Client> {
    return this.api.post<Client>('/clients', payload);
  }

  update(id: number | string, payload: ClientUpdate): Observable<Client> {
    return this.api.put<Client>(`/clients/${id}`, payload);
  }

  delete(id: number | string): Observable<void> {
    return this.api.delete<void>(`/clients/${id}`);
  }
}

