import { Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { ClientsState } from '../../state/clients.state';
import { Client } from '../../models/client.model';
import { ClientFormComponent } from '../../components/client-form/client-form.component';

@Component({
  selector: 'app-client-detail',
  standalone: true,
  imports: [NgIf, MatCardModule, MatButtonModule, ClientFormComponent],
  templateUrl: './client-detail.component.html',
  styleUrl: './client-detail.component.scss'
})
export class ClientDetailComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly state = inject(ClientsState);

  readonly client = signal<Client | null>(null);
  readonly loading = this.state.loading;
  readonly error = this.state.error;

  readonly isNew = signal(true);

  constructor() {
    const id = this.route.snapshot.paramMap.get('id');
    this.isNew.set(!id);
    if (id) {
      this.state.getById(id).subscribe({
        next: (c) => this.client.set(c),
        error: () => this.client.set(null)
      });
    }
  }

  save(payload: { name: string; email: string; phone?: string; active?: boolean }): void {
    const id = this.route.snapshot.paramMap.get('id');
    const req$ = id ? this.state.update(id, payload) : this.state.create(payload);
    req$.subscribe({
      next: () => void this.router.navigateByUrl('/clients'),
      error: () => void 0
    });
  }

  cancel(): void {
    void this.router.navigateByUrl('/clients');
  }
}
