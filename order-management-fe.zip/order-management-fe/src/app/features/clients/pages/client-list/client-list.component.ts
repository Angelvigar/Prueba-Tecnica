import { AfterViewInit, Component, ViewChild, effect, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { ClientsState } from '../../state/clients.state';
import { Client } from '../../models/client.model';
import { ConfirmDialogComponent } from '../../../../shared/components/ui/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-client-list',
  standalone: true,
  imports: [
    NgIf,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule
  ],
  templateUrl: './client-list.component.html',
  styleUrl: './client-list.component.scss'
})
export class ClientListComponent implements AfterViewInit {
  private readonly state = inject(ClientsState);
  private readonly dialog = inject(MatDialog);

  readonly nameFilter = signal('');
  readonly emailFilter = signal('');

  readonly dataSource = new MatTableDataSource<Client>([]);
  readonly displayedColumns = ['firstName', 'lastName', 'email', 'phone', 'status', 'actions'] as const;

  @ViewChild(MatPaginator) paginator?: MatPaginator;
  @ViewChild(MatSort) sort?: MatSort;

  readonly loading = this.state.loading;
  readonly error = this.state.error;

  constructor() {
    this.state.loadAll();
    this.dataSource.filterPredicate = (data, filter) => {
      const f = JSON.parse(filter) as { name: string; email: string };
      const fullName = `${data.firstName} ${data.lastName}`.toLowerCase();
      const nameOk = fullName.includes((f.name ?? '').toLowerCase());
      const emailOk = (data.email ?? '').toLowerCase().includes((f.email ?? '').toLowerCase());
      return nameOk && emailOk;
    };
    // Sincroniza signal -> dataSource
    effect(() => {
      this.dataSource.data = this.state.clients();
    });
  }

  ngAfterViewInit(): void {
    if (this.paginator) this.dataSource.paginator = this.paginator;
    if (this.sort) this.dataSource.sort = this.sort;
  }

  applyFilters(): void {
    this.dataSource.filter = JSON.stringify({
      name: this.nameFilter(),
      email: this.emailFilter()
    });
    if (this.dataSource.paginator) this.dataSource.paginator.firstPage();
  }

  confirmDelete(client: Client): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      data: {
        title: 'Eliminar cliente',
        message: `¿Deseas eliminar a "${client.firstName} ${client.lastName}"?`
      }
    });

    ref.afterClosed().subscribe((ok: boolean) => {
      if (!ok) return;
      this.state.remove(client.id).subscribe({
        next: () => this.state.loadAll()
      });
    });
  }
}
