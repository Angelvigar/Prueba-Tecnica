export interface Role {
  id: number;
  name: 'Admin' | 'Gestor' | 'Consultor';
  description: string;
}

export const ROLES: Role[] = [
  { id: 1, name: 'Admin', description: 'Acceso total al sistema' },
  { id: 2, name: 'Gestor', description: 'Gestión de clientes y pedidos' },
  { id: 3, name: 'Consultor', description: 'Solo lectura' }
];

// Solo necesitas este modelo para registro
export interface UserRegister {
  username: string;
  email: string;
  password: string;
  roleId: number;
}
