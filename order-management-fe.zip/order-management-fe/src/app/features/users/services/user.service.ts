import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api/api.service';
import { ApiConfigService } from '../../../core/services/api/api-config.service';
import { UserRegister } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private readonly api = inject(ApiService);
  private readonly config = inject(ApiConfigService);

  register(user: UserRegister): Observable<{ message: string }> {
    const baseUrl = this.config.authUrl.replace(/\/$/, '');
    return this.api.post<{ message: string }>(`${baseUrl}/register`, user);
  }

}
