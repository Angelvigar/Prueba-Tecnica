import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { Client } from '../../../clients/models/client.model';
import { ClientService } from '../../../clients/services/client.service';
import { Order } from '../../models/order.model';
import { toIsoDateInput } from '../../../../shared/utils/date.helpers';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './order-form.component.html',
  styleUrl: './order-form.component.scss'
})
export class OrderFormComponent {
  private readonly fb = inject(FormBuilder);
  private readonly clientsService = inject(ClientService);

  @Input() set value(v: Order | null | undefined) {
    if (!v) return;
    this.form.patchValue({
      clientId: v.clientId,
      date: new Date(v.date),
      amount: v.amount,
      notes: v.notes ?? ''
    });
  }

  @Input() saving = false;
  @Output() saveOrder = new EventEmitter<{ clientId: number; date: string; amount: number; notes?: string }>();
  @Output() cancel = new EventEmitter<void>();

  readonly clients = signal<Client[]>([]);
  readonly clientsLoading = signal(false);

  readonly form = this.fb.nonNullable.group({
    clientId: [0, [Validators.required, Validators.min(1)]],
    date: [new Date(), [Validators.required]],
    amount: [0, [Validators.required, Validators.min(0.01)]],
    notes: ['']
  });

  constructor() {
    this.loadClients();
  }

  private loadClients(): void {
    this.clientsLoading.set(true);
    this.clientsService.getAll().subscribe({
      next: (c) => this.clients.set(c ?? []),
      error: () => this.clients.set([]),
      complete: () => this.clientsLoading.set(false)
    });
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();
    const dateIso = toIsoDateInput(v.date);
    this.saveOrder.emit({
      clientId: Number(v.clientId),
      date: dateIso,
      amount: Number(v.amount),
      notes: v.notes?.trim() || undefined
    });
  }
}
