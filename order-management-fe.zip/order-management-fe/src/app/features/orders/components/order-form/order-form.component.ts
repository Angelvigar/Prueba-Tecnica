import { Component, EventEmitter, Input, Output, inject, signal } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { Client } from '../../../clients/models/client.model';
import { ClientService } from '../../../clients/services/client.service';
import { Order, OrderCreate, OrderUpdate } from '../../models/order.model';

@Component({
  selector: 'app-order-form',
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule
  ],
  templateUrl: './order-form.component.html',
  styleUrl: './order-form.component.scss'
})
export class OrderFormComponent {
  private readonly fb = inject(FormBuilder);
  private readonly clientsService = inject(ClientService);

  @Input() set value(v: Order | null | undefined) {
    if (!v) {
      this.isEditMode.set(false);
      this.form.enable();
      this.currentOrderState.set(null);
      return;
    }
    this.isEditMode.set(true);
    this.currentOrderState.set(v.orderState);
    this.form.patchValue({
      clientId: v.clientId,
      totalAmount: v.totalAmount,
      description: v.description ?? ''
    });

    // En modo edición, deshabilitar el campo de cliente
    this.form.controls.clientId.disable();

    // Si el pedido está completado o cancelado, deshabilitar todo el formulario
    if (v.orderState === 'Completado' || v.orderState === 'Cancelado') {
      this.form.disable();
      this.isReadOnly.set(true);
    } else {
      this.form.controls.totalAmount.enable();
      this.form.controls.description.enable();
      this.isReadOnly.set(false);
    }
  }

  @Input() saving = false;
  @Output() saveOrder = new EventEmitter<OrderCreate | OrderUpdate>();
  @Output() cancel = new EventEmitter<void>();

  readonly clients = signal<Client[]>([]);
  readonly clientsLoading = signal(false);
  readonly isEditMode = signal(false);
  readonly isReadOnly = signal(false);
  readonly currentOrderState = signal<string | null>(null);

  readonly form = this.fb.nonNullable.group({
    clientId: [0, [Validators.required, Validators.min(1)]],
    totalAmount: [0, [Validators.required, Validators.min(0.01)]],
    description: ['']
  });

  constructor() {
    this.loadClients();
  }

  private loadClients(): void {
    this.clientsLoading.set(true);
    this.clientsService.getAll().subscribe({
      next: (c) => this.clients.set(c ?? []),
      error: () => this.clients.set([]),
      complete: () => this.clientsLoading.set(false)
    });
  }

  submit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const v = this.form.getRawValue();

    if (this.isEditMode()) {
      // Modo edición: solo enviar totalAmount y description
      const updatePayload: OrderUpdate = {
        totalAmount: Number(v.totalAmount),
        description: v.description?.trim() || undefined
      };
      this.saveOrder.emit(updatePayload);
    } else {
      // Modo creación: enviar clientId, totalAmount y description
      const createPayload: OrderCreate = {
        clientId: Number(v.clientId),
        totalAmount: Number(v.totalAmount),
        description: v.description?.trim() || undefined
      };
      this.saveOrder.emit(createPayload);
    }
  }
}
