export type OrderStatus = 'Pendiente' | 'Completado' | 'Cancelado';

export interface Order {
  id: number;
  clientId: number;
  clientName?: string;
  date: string; // ISO
  status: OrderStatus;
  amount: number;
  notes?: string;
}

export interface OrderCreate {
  clientId: number;
  date: string;
  amount: number;
  notes?: string;
}

export interface OrderUpdate extends OrderCreate {
  status?: OrderStatus;
}

