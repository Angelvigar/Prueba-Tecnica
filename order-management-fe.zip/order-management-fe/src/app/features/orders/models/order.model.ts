export type OrderStatus = 'Pendiente' | 'Completado' | 'Cancelado';

export interface Order {
  id: number;
  clientId: number;
  clientName?: string;
  orderDate: string;
  orderState: OrderStatus;
  totalAmount: number;
  description?: string;
}

export interface OrderCreate {
  clientId: number;
  totalAmount: number;
  description?: string;
}

export interface OrderUpdate {
  totalAmount?: number;
  description?: string;
}
