import { Routes } from '@angular/router';
import { MainLayoutComponent } from '../../shared/layouts/main-layout/main-layout.component';
import { OrderDetailComponent } from './pages/order-detail/order-detail.component';
import { OrderListComponent } from './pages/order-list/order-list.component';

export const ORDERS_ROUTES: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      { path: '', component: OrderListComponent },
      { path: 'new', component: OrderDetailComponent },
      { path: ':id', component: OrderDetailComponent }
    ]
  }
];

