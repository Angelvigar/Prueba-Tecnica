import { Injectable, computed, inject, signal } from '@angular/core';
import { finalize } from 'rxjs';
import { OrderService } from '../services/order.service';
import { Order, OrderCreate, OrderStatus, OrderUpdate } from '../models/order.model';

@Injectable({ providedIn: 'root' })
export class OrdersState {
  private readonly service = inject(OrderService);

  private readonly ordersSignal = signal<Order[]>([]);
  readonly orders = this.ordersSignal.asReadonly();

  private readonly loadingSignal = signal(false);
  readonly loading = this.loadingSignal.asReadonly();

  private readonly errorSignal = signal<string | null>(null);
  readonly error = this.errorSignal.asReadonly();

  readonly totals = computed(() => ({
    total: this.ordersSignal().length,
    completed: this.ordersSignal().filter((o) => o.orderState === 'Completado').length,
    pending: this.ordersSignal().filter((o) => o.orderState === 'Pendiente').length
  }));

  loadAll(): void {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    this.service
      .getAll()
      .pipe(finalize(() => this.loadingSignal.set(false)))
      .subscribe({
        next: (items) => this.ordersSignal.set(items ?? []),
        error: (e: unknown) => this.errorSignal.set(e instanceof Error ? e.message : 'No se pudieron cargar pedidos.')
      });
  }

  filter(params: { state?: OrderStatus; clientId?: number | string; dateFrom?: string; dateTo?: string }): void {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    this.service
      .filter(params)
      .pipe(finalize(() => this.loadingSignal.set(false)))
      .subscribe({
        next: (items) => this.ordersSignal.set(items ?? []),
        error: (e: unknown) => this.errorSignal.set(e instanceof Error ? e.message : 'No se pudieron filtrar pedidos.')
      });
  }

  getById(id: number | string) {
    return this.service.getById(id);
  }

  create(payload: OrderCreate) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.create(payload).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  update(id: number | string, payload: OrderUpdate) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.update(id, payload).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  complete(id: number | string) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.complete(id).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  cancel(id: number | string) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.cancel(id).pipe(finalize(() => this.loadingSignal.set(false)));
  }

  remove(id: number | string) {
    this.loadingSignal.set(true);
    this.errorSignal.set(null);
    return this.service.delete(id).pipe(finalize(() => this.loadingSignal.set(false)));
  }
}
