import { Component, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { OrdersState } from '../../state/orders.state';
import { Order, OrderCreate, OrderUpdate } from '../../models/order.model';
import { OrderFormComponent } from '../../components/order-form/order-form.component';

@Component({
  selector: 'app-order-detail',
  standalone: true,
  imports: [NgIf, MatCardModule, MatButtonModule, OrderFormComponent],
  templateUrl: './order-detail.component.html',
  styleUrl: './order-detail.component.scss'
})
export class OrderDetailComponent {
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly state = inject(OrdersState);

  readonly order = signal<Order | null>(null);
  readonly loading = this.state.loading;
  readonly error = this.state.error;

  readonly isNew = signal(true);

  constructor() {
    const id = this.route.snapshot.paramMap.get('id');
    this.isNew.set(!id);
    if (id) {
      this.state.getById(id).subscribe({
        next: (o) => this.order.set(o),
        error: () => this.order.set(null)
      });
    }
  }

  save(payload: OrderCreate | OrderUpdate): void {
    const id = this.route.snapshot.paramMap.get('id');
    const req$ = id ? this.state.update(id, payload as OrderUpdate) : this.state.create(payload as OrderCreate);
    req$.subscribe({
      next: () => void this.router.navigateByUrl('/orders')
    });
  }

  cancel(): void {
    void this.router.navigateByUrl('/orders');
  }
}
