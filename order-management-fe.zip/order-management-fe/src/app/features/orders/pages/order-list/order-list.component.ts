import { AfterViewInit, Component, ViewChild, effect, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog } from '@angular/material/dialog';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { OrdersState } from '../../state/orders.state';
import { Order, OrderStatus } from '../../models/order.model';
import { Client } from '../../../clients/models/client.model';
import { ClientService } from '../../../clients/services/client.service';
import { ConfirmDialogComponent } from '../../../../shared/components/ui/confirm-dialog/confirm-dialog.component';
import { toIsoDateInput } from '../../../../shared/utils/date.helpers';

@Component({
  selector: 'app-order-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.scss'
})
export class OrderListComponent implements AfterViewInit {
  private readonly state = inject(OrdersState);
  private readonly clientsService = inject(ClientService);
  private readonly dialog = inject(MatDialog);

  readonly clients = signal<Client[]>([]);

  readonly status = signal<OrderStatus | ''>('');
  readonly clientId = signal<number | ''>('');
  readonly dateFrom = signal<Date | null>(null);
  readonly dateTo = signal<Date | null>(null);

  readonly dataSource = new MatTableDataSource<Order>([]);
  readonly displayedColumns = ['client', 'date', 'status', 'amount', 'actions'] as const;

  @ViewChild(MatPaginator) paginator?: MatPaginator;
  @ViewChild(MatSort) sort?: MatSort;

  readonly loading = this.state.loading;
  readonly error = this.state.error;

  readonly statuses: OrderStatus[] = ['Pendiente', 'Completado', 'Cancelado'];

  constructor() {
    this.state.loadAll();
    this.clientsService.getAll().subscribe({
      next: (c) => this.clients.set(c ?? []),
      error: () => this.clients.set([])
    });

    effect(() => {
      this.dataSource.data = this.state.orders();
    });
  }

  ngAfterViewInit(): void {
    if (this.paginator) this.dataSource.paginator = this.paginator;
    if (this.sort) this.dataSource.sort = this.sort;
  }

  applyFilters(): void {
    const hasAny =
      !!this.status() || !!this.clientId() || !!this.dateFrom() || !!this.dateTo();

    if (!hasAny) {
      this.state.loadAll();
      return;
    }

    this.state.filter({
      state: (this.status() as OrderStatus) || undefined,
      clientId: this.clientId() || undefined,
      dateFrom: this.dateFrom() ? toIsoDateInput(this.dateFrom()!) : undefined,
      dateTo: this.dateTo() ? toIsoDateInput(this.dateTo()!) : undefined
    });
  }

  clearFilters(): void {
    this.status.set('');
    this.clientId.set('');
    this.dateFrom.set(null);
    this.dateTo.set(null);
    this.state.loadAll();
  }

  confirmDelete(order: Order): void {
    const ref = this.dialog.open(ConfirmDialogComponent, {
      data: { title: 'Eliminar pedido', message: `¿Eliminar el pedido #${order.id}?` }
    });
    ref.afterClosed().subscribe((ok: boolean) => {
      if (!ok) return;
      this.state.remove(order.id).subscribe({ next: () => this.state.loadAll() });
    });
  }

  markComplete(order: Order): void {
    this.state.complete(order.id).subscribe({ next: () => this.applyFilters() });
  }

  markCancel(order: Order): void {
    this.state.cancel(order.id).subscribe({ next: () => this.applyFilters() });
  }
}
