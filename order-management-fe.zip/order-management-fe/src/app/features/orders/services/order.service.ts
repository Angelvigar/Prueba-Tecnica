import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../core/services/api/api.service';
import { Order, OrderCreate, OrderStatus, OrderUpdate } from '../models/order.model';

@Injectable({ providedIn: 'root' })
export class OrderService {
  private readonly api = inject(ApiService);

  getAll(): Observable<Order[]> {
    return this.api.get<Order[]>('/orders');
  }

  getById(id: number | string): Observable<Order> {
    return this.api.get<Order>(`/orders/${id}`);
  }

  filter(params: { state?: OrderStatus; clientId?: number | string; dateFrom?: string; dateTo?: string }): Observable<Order[]> {
    // El backend especificado incluye /orders/filter?state=Pendiente&clientId=1
    return this.api.get<Order[]>('/orders/filter', {
      state: params.state ?? null,
      clientId: params.clientId ?? null,
      dateFrom: params.dateFrom ?? null,
      dateTo: params.dateTo ?? null
    });
  }

  create(payload: OrderCreate): Observable<Order> {
    return this.api.post<Order>('/orders', payload);
  }

  update(id: number | string, payload: OrderUpdate): Observable<Order> {
    return this.api.put<Order>(`/orders/${id}`, payload);
  }

  complete(id: number | string): Observable<Order> {
    return this.api.patch<Order>(`/orders/${id}/complete`);
  }

  cancel(id: number | string): Observable<Order> {
    return this.api.patch<Order>(`/orders/${id}/cancel`);
  }

  delete(id: number | string): Observable<void> {
    return this.api.delete<void>(`/orders/${id}`);
  }
}

