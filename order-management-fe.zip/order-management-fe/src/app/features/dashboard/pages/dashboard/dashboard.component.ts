import { Component, computed, inject, signal } from '@angular/core';
import { NgIf } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { ApiService } from '../../../../core/services/api/api.service';
import { StatsCardComponent } from '../../components/stats-card/stats-card.component';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration } from 'chart.js';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [NgIf, MatCardModule, MatButtonModule, StatsCardComponent, BaseChartDirective],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  private readonly api = inject(ApiService);

  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  readonly stats = signal<DashboardStatistics | null>(null);
  readonly dailyActivity = signal<ActivityPoint[]>([]);
  readonly monthlyActivity = signal<ActivityPoint[]>([]);

  readonly completedSubtitle = computed(() => {
    const s = this.stats();
    if (!s) return '';
    return `${s.completedOrders} completados / ${s.pendingOrders} pendientes`;
  });

  readonly dailyChartData = computed<ChartConfiguration<'line'>['data']>(() => {
    const data = this.dailyActivity();
    return {
      labels: data.map((d) => d.label),
      datasets: [
        {
          data: data.map((d) => d.value),
          label: 'Pedidos por día',
          fill: true,
          tension: 0.3,
          borderColor: 'rgba(63, 81, 181, 1)',
          backgroundColor: 'rgba(63, 81, 181, 0.3)',
          pointRadius: 3
        }
      ]
    };
  });

  readonly dailyChartOptions: ChartConfiguration<'line'>['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        ticks: { maxRotation: 0, autoSkip: true }
      },
      y: {
        beginAtZero: true,
        ticks: { precision: 0 }
      }
    }
  };

  readonly monthlyChartData = computed<ChartConfiguration<'bar'>['data']>(() => {
    const data = this.monthlyActivity();
    return {
      labels: data.map((d) => d.label),
      datasets: [
        {
          data: data.map((d) => d.value),
          label: 'Pedidos por mes',
          borderColor: 'rgba(0, 150, 136, 1)',
          backgroundColor: 'rgba(0, 150, 136, 0.4)'
        }
      ]
    };
  });

  readonly monthlyChartOptions: ChartConfiguration<'bar'>['options'] = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false }
    },
    scales: {
      x: {
        ticks: { maxRotation: 0, autoSkip: true }
      },
      y: {
        beginAtZero: true,
        ticks: { precision: 0 }
      }
    }
  };

  constructor() {
    this.reload();
  }

  reload(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.get<DashboardResponse>('/Dashboard').subscribe({
      next: (res) => {
        this.stats.set(res.stats);
        this.dailyActivity.set(res.dailyActivity ?? []);
        this.monthlyActivity.set(res.monthlyActivity ?? []);
      },
      error: (e: unknown) =>
        this.error.set(e instanceof Error ? e.message : 'No se pudieron cargar estadísticas.'),
      complete: () => this.loading.set(false)
    });
  }

  maxCount(items: Array<{ date: string; count: number }>): number {
    return items.reduce((max, it) => Math.max(max, it.count || 0), 0);
  }
}

interface DashboardStatistics {
  totalOrders: number;
  completedOrders: number;
  pendingOrders: number;
  activeClients: number;
}

interface ActivityPoint {
  label: string;
  value: number;
}

interface DashboardResponse {
  stats: DashboardStatistics;
  dailyActivity: ActivityPoint[];
  monthlyActivity: ActivityPoint[];
}
