import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-stats-card',
  standalone: true,
  imports: [NgIf, MatCardModule, MatIconModule],
  templateUrl: './stats-card.component.html',
  styleUrl: './stats-card.component.scss'
})
export class StatsCardComponent {
  @Input({ required: true }) title = '';
  @Input() subtitle?: string;
  @Input({ required: true }) value: string | number = '';
  @Input() icon?: string;
}
