import { Routes } from '@angular/router';
import { authGuard } from './core/auth/guards/auth.guard';
import { roleGuard } from './core/auth/guards/role.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  {
    path: 'auth',
    loadChildren: () =>
      import('./features/auth/auth.routes').then((m) => m.AUTH_ROUTES)
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadChildren: () =>
      import('./features/dashboard/dashboard.routes').then((m) => m.DASHBOARD_ROUTES)
  },
  {
    path: 'clients',
    canActivate: [authGuard, roleGuard(['Admin', 'Gestor'])],
    loadChildren: () =>
      import('./features/clients/clients.routes').then((m) => m.CLIENTS_ROUTES)
  },
  {
    path: 'orders',
    canActivate: [authGuard, roleGuard(['Admin', 'Gestor'])],
    loadChildren: () =>
      import('./features/orders/orders.routes').then((m) => m.ORDERS_ROUTES)
  },
  {
    path: 'users',
    canActivate: [authGuard, roleGuard(['Admin'])],
    loadChildren: () =>
      import('./features/users/users.routes').then((m) => m.USERS_ROUTES)
  },
  { path: '**', redirectTo: '/dashboard' }
];
