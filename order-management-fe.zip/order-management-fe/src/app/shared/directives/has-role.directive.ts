import { Directive, Input, TemplateRef, ViewContainerRef, effect, inject } from '@angular/core';
import { Role } from '../../core/auth/models/auth.model';
import { AuthService } from '../../core/auth/services/auth.service';

@Directive({
  selector: '[hasRole]',
  standalone: true
})
export class HasRoleDirective {
  private readonly tpl = inject(TemplateRef<unknown>);
  private readonly vcr = inject(ViewContainerRef);
  private readonly auth = inject(AuthService);

  private expected: Role[] = [];
  private hasView = false;

  @Input('hasRole')
  set hasRole(roles: Role[]) {
    this.expected = roles ?? [];
    this.update();
  }

  constructor() {
    // Reactivo: si cambian roles (signals), actualizamos la vista.
    effect(() => {
      void this.auth.roles();
      this.update();
    });
  }

  private update(): void {
    const allowed = this.auth.hasAnyRole(this.expected);
    if (allowed && !this.hasView) {
      this.vcr.clear();
      this.vcr.createEmbeddedView(this.tpl);
      this.hasView = true;
      return;
    }

    if (!allowed && this.hasView) {
      this.vcr.clear();
      this.hasView = false;
    }
  }
}

