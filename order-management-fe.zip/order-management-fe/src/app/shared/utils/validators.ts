import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export const minTrimmedLength =
  (min: number): ValidatorFn =>
  (control: AbstractControl): ValidationErrors | null => {
    const v = (control.value ?? '').toString().trim();
    if (!v) return null;
    return v.length >= min ? null : { minTrimmedLength: { requiredLength: min, actualLength: v.length } };
  };

