import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-OGW4DSKS.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-E65F55UL.js";
import "./chunk-I75JAFX5.js";
import "./chunk-QVRY7S7I.js";
import "./chunk-X5ZJAZ7S.js";
import "./chunk-FFY7VSBW.js";
import "./chunk-PCGAWVWW.js";
import "./chunk-E5ECCKE6.js";
import "./chunk-WDMUDEB6.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
