﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace order.be.api.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly ILogger<OrdersController> _logger;

        public OrdersController(IOrderService orderService, ILogger<OrdersController> logger)
        {
            _orderService = orderService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var orders = await _orderService.GetAllAsync();
                return Ok(orders);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener pedidos");
                return StatusCode(500, new { error = "Error al obtener los pedidos" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var order = await _orderService.GetByIdAsync(id);
                return Ok(order);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener pedido {Id}", id);
                return StatusCode(500, new { error = "Error al obtener el pedido" });
            }
        }

        [HttpGet("filter")]
        public async Task<IActionResult> GetFiltered([FromQuery] OrderFilterRequest filters)
        {
            try
            {
                var orders = await _orderService.GetFilteredAsync(filters);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al filtrar pedidos");
                return StatusCode(500, new { error = "Error al filtrar los pedidos" });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Create([FromBody] CreateOrderRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                var order = await _orderService.CreateAsync(request, username);

                _logger.LogInformation("Usuario {Username} creó pedido {OrderId}", username, order.Id);
                return CreatedAtAction(nameof(GetById), new { id = order.Id }, order);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al crear pedido");
                return StatusCode(500, new { error = "Error al crear el pedido" });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateOrderRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                await _orderService.UpdateAsync(id, request, username);

                _logger.LogInformation("Usuario {Username} actualizó pedido {OrderId}", username, id);
                return Ok(new { message = "Pedido actualizado exitosamente" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al actualizar pedido {Id}", id);
                return StatusCode(500, new { error = "Error al actualizar el pedido" });
            }
        }

        [HttpPatch("{id}/complete")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> MarkAsCompleted(int id)
        {
            try
            {
                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                await _orderService.MarkAsCompletedAsync(id, username);

                _logger.LogInformation("Usuario {Username} completó pedido {OrderId}", username, id);
                return Ok(new { message = "Pedido marcado como completado" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al completar pedido {Id}", id);
                return StatusCode(500, new { error = "Error al completar el pedido" });
            }
        }

        [HttpPatch("{id}/cancel")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> MarkAsCancelled(int id)
        {
            try
            {
                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                await _orderService.MarkAsCancelledAsync(id, username);

                _logger.LogInformation("Usuario {Username} canceló pedido {OrderId}", username, id);
                return Ok(new { message = "Pedido cancelado" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al cancelar pedido {Id}", id);
                return StatusCode(500, new { error = "Error al cancelar el pedido" });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _orderService.DeleteAsync(id);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                _logger.LogInformation("Usuario {Username} eliminó pedido {OrderId}", username, id);

                return Ok(new { message = "Pedido eliminado exitosamente" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al eliminar pedido {Id}", id);
                return StatusCode(500, new { error = "Error al eliminar el pedido" });
            }
        }
    }
}
