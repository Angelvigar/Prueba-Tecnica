﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;
using order.be.application.Models.Response;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace order.be.api.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderResponse>>> GetAll() =>
            Ok(await _orderService.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<OrderResponse>> GetById(int id) =>
            Ok(await _orderService.GetByIdAsync(id));

        [HttpGet("filter")]
        public async Task<ActionResult<IEnumerable<OrderResponse>>> GetFiltered([FromQuery] OrderFilterRequest filters) =>
            Ok(await _orderService.GetFilteredAsync(filters));

        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<OrderResponse>> Create([FromBody] CreateOrderRequest request)
        {
            var user = User.Identity?.Name ?? "SYSTEM";
            var order = await _orderService.CreateAsync(request, user);
            return CreatedAtAction(nameof(GetById), new { id = order.Id }, order);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateOrderRequest request)
        {
            await _orderService.UpdateAsync(id, request, User.Identity?.Name ?? "SYSTEM");
            return Ok(new { message = "Pedido actualizado exitosamente" });
        }

        [HttpPatch("{id}/complete")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> MarkAsCompleted(int id)
        {
            await _orderService.MarkAsCompletedAsync(id, User.Identity?.Name ?? "SYSTEM");
            return Ok(new { message = "Pedido completado" });
        }

        [HttpPatch("{id}/cancel")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> MarkAsCancelled(int id)
        {
            await _orderService.MarkAsCancelledAsync(id, User.Identity?.Name ?? "SYSTEM");
            return Ok(new { message = "Pedido cancelado" });
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _orderService.DeleteAsync(id);
            return Ok(new { message = "Pedido eliminado exitosamente" });
        }
    }
}
