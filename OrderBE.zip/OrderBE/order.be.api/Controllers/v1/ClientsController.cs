﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;
using order.be.application.Models.Response;

namespace order.be.api.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ClientsController : ControllerBase
    {
        private readonly IClientService _clientService;

        public ClientsController(IClientService clientService)
        {
            _clientService = clientService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClientResponse>>> GetAll()
        {
            return Ok(await _clientService.GetAllAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ClientResponse>> GetById(int id)
        {
            return Ok(await _clientService.GetByIdAsync(id));
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<ActionResult<ClientResponse>> Create([FromBody] CreateClientRequest request)
        {
            var username = User.Identity?.Name ?? "SYSTEM";
            var client = await _clientService.CreateAsync(request, username);
            return CreatedAtAction(nameof(GetById), new { id = client.Id }, client);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateClientRequest request)
        {
            var username = User.Identity?.Name ?? "SYSTEM";
            await _clientService.UpdateAsync(id, request, username);
            return Ok(new { message = "Cliente actualizado exitosamente" });
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            await _clientService.DeleteAsync(id);
            return Ok(new { message = "Cliente eliminado exitosamente" });
        }
    }
}