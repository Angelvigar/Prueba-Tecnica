﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace order.be.api.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize]
    public class ClientsController : ControllerBase
    {
        private readonly IClientService _clientService;
        private readonly ILogger<ClientsController> _logger;

        public ClientsController(IClientService clientService, ILogger<ClientsController> logger)
        {
            _clientService = clientService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            try
            {
                var clients = await _clientService.GetAllAsync();
                return Ok(clients);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener clientes");
                return StatusCode(500, new { error = "Error al obtener los clientes" });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var client = await _clientService.GetByIdAsync(id);
                return Ok(client);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al obtener cliente {Id}", id);
                return StatusCode(500, new { error = "Error al obtener el cliente" });
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Create([FromBody] CreateClientRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                var client = await _clientService.CreateAsync(request, username);

                _logger.LogInformation("Usuario {Username} creó cliente {ClientId}", username, client.Id);
                return CreatedAtAction(nameof(GetById), new { id = client.Id }, client);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al crear cliente");
                return StatusCode(500, new { error = "Error al crear el cliente" });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Gestor")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateClientRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                await _clientService.UpdateAsync(id, request, username);

                _logger.LogInformation("Usuario {Username} actualizó cliente {ClientId}", username, id);
                return Ok(new { message = "Cliente actualizado exitosamente" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al actualizar cliente {Id}", id);
                return StatusCode(500, new { error = "Error al actualizar el cliente" });
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                await _clientService.DeleteAsync(id);

                var username = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "SYSTEM";
                _logger.LogInformation("Usuario {Username} eliminó cliente {ClientId}", username, id);

                return Ok(new { message = "Cliente eliminado exitosamente" });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al eliminar cliente {Id}", id);
                return StatusCode(500, new { error = "Error al eliminar el cliente" });
            }
        }
    }
}
