﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.domain.Entity
{
    public class Order : BaseEntity
    {
        public int ClientId { get; set; }
        public virtual Client Client { get; set; } = null!;

        public DateTime OrderDate { get; set; } = DateTime.UtcNow;

        public string OrderState { get; set; } = "Pendiente";

        public decimal TotalAmount { get; set; }

        public string? Description { get; set; }
    }
}
