﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.domain.Entity
{
    public abstract class BaseEntity
    {
        public int Id { get; set; }
        public bool Status { get; set; } = true;
        public string CreationUser { get; set; } = "SYSTEM";
        public DateTime CreationDate { get; set; } = DateTime.UtcNow;
        public string? ModificationUser { get; set; }
        public DateTime? ModificationDate { get; set; }
    }
}
