﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Models.Request
{
    public class UpdateOrderRequest
    {
        [Range(0.01, double.MaxValue)]
        public decimal? TotalAmount { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }
    }
}
