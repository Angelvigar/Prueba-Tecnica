﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Models.Request
{
    public class OrderFilterRequest
    {
        public string? State { get; set; }
        public DateTime? Date { get; set; } 
        public int? ClientId { get; set; }
    }
}
