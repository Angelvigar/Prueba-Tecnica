﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Models.Response
{
    public class OrderResponse
    {
        public int Id { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; } 
        public string ClientEmail { get; set; } 
        public DateTime OrderDate { get; set; }
        public string OrderState { get; set; } 
        public decimal TotalAmount { get; set; }
        public string? Description { get; set; }
        public bool Status { get; set; }
    }
}
