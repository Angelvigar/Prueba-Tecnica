﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Models.Response
{
    public record DashboardStats(int TotalOrders, int CompletedOrders, int PendingOrders, int ActiveClients);

    public record ChartData(string Label, int Value);

    public record DashboardResponse(
        DashboardStats Stats,
        IEnumerable<ChartData> DailyActivity,
        IEnumerable<ChartData> MonthlyActivity
        );
}
