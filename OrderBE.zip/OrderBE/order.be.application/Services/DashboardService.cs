﻿using order.be.application.Interfaces.Repository;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IDashboardRepository _repo;
        public DashboardService(IDashboardRepository repo) => _repo = repo;

        public async Task<DashboardResponse> GetDashboardDataAsync() => await _repo.GetSummaryAsync();
    }
}
