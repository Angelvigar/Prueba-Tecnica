﻿using AutoMapper;
using order.be.application.Interfaces.Repository;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;
using order.be.application.Models.Response;
using order.be.domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Services
{
    public class ClientService : IClientService
    {
        private readonly IClientRepository _repository;
        private readonly IMapper _mapper;

        public ClientService(IClientRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<ClientResponse> GetByIdAsync(int id)
        {
            var client = await _repository.GetByIdAsync(id);
            if (client == null)
                throw new KeyNotFoundException($"Cliente con ID {id} no encontrado");

            return _mapper.Map<ClientResponse>(client);
        }

        public async Task<IEnumerable<ClientResponse>> GetAllAsync()
        {
            var clients = await _repository.GetAllAsync();
            return _mapper.Map<IEnumerable<ClientResponse>>(clients);
        }

        public async Task<ClientResponse> CreateAsync(CreateClientRequest request, string creationUser)
        {
            if (await _repository.ExistsByEmailAsync(request.Email))
                throw new InvalidOperationException($"Ya existe un cliente con el email {request.Email}");

            var client = _mapper.Map<Client>(request);
            client.CreationUser = creationUser;
            client.CreationDate = DateTime.UtcNow;

            var created = await _repository.CreateAsync(client);
            return _mapper.Map<ClientResponse>(created);
        }

        public async Task UpdateAsync(int id, UpdateClientRequest request, string modificationUser)
        {
            var client = await _repository.GetByIdAsync(id);
            if (client == null)
                throw new KeyNotFoundException($"Cliente con ID {id} no encontrado");

            if (request.Email != null && request.Email != client.Email)
            {
                if (await _repository.ExistsByEmailAsync(request.Email))
                    throw new InvalidOperationException($"Ya existe un cliente con el email {request.Email}");
                client.Email = request.Email;
            }

            if (request.FirstName != null) client.FirstName = request.FirstName;
            if (request.LastName != null) client.LastName = request.LastName;
            if (request.Phone != null) client.Phone = request.Phone;

            client.ModificationUser = modificationUser;
            client.ModificationDate = DateTime.UtcNow;

            await _repository.UpdateAsync(client);
        }

        public async Task DeleteAsync(int id)
        {
            var client = await _repository.GetByIdAsync(id);
            if (client == null)
                throw new KeyNotFoundException($"Cliente con ID {id} no encontrado");

            await _repository.DeleteAsync(id);
        }
    }
}
