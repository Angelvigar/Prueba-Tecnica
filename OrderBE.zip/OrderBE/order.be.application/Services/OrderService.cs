﻿using AutoMapper;
using order.be.application.Interfaces.Repository;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;
using order.be.application.Models.Response;
using order.be.domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IMapper _mapper;

        public OrderService(IOrderRepository orderRepository, IClientRepository clientRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _clientRepository = clientRepository;
            _mapper = mapper;
        }

        public async Task<OrderResponse> GetByIdAsync(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido {id} no encontrado.");

            return _mapper.Map<OrderResponse>(order);
        }

        public async Task<IEnumerable<OrderResponse>> GetAllAsync() =>
            _mapper.Map<IEnumerable<OrderResponse>>(await _orderRepository.GetAllAsync());

        public async Task<IEnumerable<OrderResponse>> GetFilteredAsync(OrderFilterRequest filters) =>
            _mapper.Map<IEnumerable<OrderResponse>>(await _orderRepository.GetFilteredAsync(filters.State, filters.Date, filters.ClientId));

        public async Task<OrderResponse> CreateAsync(CreateOrderRequest request, string creationUser)
        {
            var client = await _clientRepository.GetByIdAsync(request.ClientId);
            if (client == null)
                throw new InvalidOperationException($"Operación inválida: El cliente {request.ClientId} no existe.");

            var order = _mapper.Map<Order>(request);
            order.OrderState = "Pendiente";
            order.CreationUser = creationUser;

            return _mapper.Map<OrderResponse>(await _orderRepository.CreateAsync(order));
        }

        public async Task UpdateAsync(int id, UpdateOrderRequest request, string modificationUser)
        {
            var order = await GetOrderOrThrow(id);

            if (order.OrderState is "Completado" or "Cancelado")
                throw new InvalidOperationException("No se pueden modificar pedidos en estado final.");

            if (request.TotalAmount.HasValue) order.TotalAmount = request.TotalAmount.Value;
            if (request.Description != null) order.Description = request.Description;

            order.ModificationUser = modificationUser;
            order.ModificationDate = DateTime.UtcNow;

            await _orderRepository.UpdateAsync(order);
        }

        public async Task MarkAsCompletedAsync(int id, string modificationUser)
        {
            var order = await GetOrderOrThrow(id);
            if (order.OrderState == "Cancelado")
                throw new InvalidOperationException("No se puede completar un pedido cancelado.");

            order.OrderState = "Completado";
            order.ModificationUser = modificationUser;
            await _orderRepository.UpdateAsync(order);
        }

        public async Task MarkAsCancelledAsync(int id, string modificationUser)
        {
            var order = await GetOrderOrThrow(id);
            if (order.OrderState == "Completado")
                throw new InvalidOperationException("No se puede cancelar un pedido completado.");

            order.OrderState = "Cancelado";
            order.ModificationUser = modificationUser;
            await _orderRepository.UpdateAsync(order);
        }

        public async Task DeleteAsync(int id)
        {
            var order = await GetOrderOrThrow(id);

            await _orderRepository.UpdateStatusAsync(order);
        }

        private async Task<Order> GetOrderOrThrow(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null) throw new KeyNotFoundException($"Pedido {id} no encontrado.");
            return order;
        }
    }
}