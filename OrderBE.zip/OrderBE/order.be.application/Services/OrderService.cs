﻿using AutoMapper;
using order.be.application.Interfaces.Repository;
using order.be.application.Interfaces.Service;
using order.be.application.Models.Request;
using order.be.application.Models.Response;
using order.be.domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Services
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IClientRepository _clientRepository;
        private readonly IMapper _mapper;

        public OrderService(IOrderRepository orderRepository, IClientRepository clientRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _clientRepository = clientRepository;
            _mapper = mapper;
        }

        public async Task<OrderResponse> GetByIdAsync(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido con ID {id} no encontrado");

            return _mapper.Map<OrderResponse>(order);
        }

        public async Task<IEnumerable<OrderResponse>> GetAllAsync()
        {
            var orders = await _orderRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<OrderResponse>>(orders);
        }

        public async Task<IEnumerable<OrderResponse>> GetFilteredAsync(OrderFilterRequest filters)
        {
            var orders = await _orderRepository.GetFilteredAsync(
                filters.State,
                filters.Date,
                filters.ClientId);

            return _mapper.Map<IEnumerable<OrderResponse>>(orders);
        }

        public async Task<OrderResponse> CreateAsync(CreateOrderRequest request, string creationUser)
        {
            var client = await _clientRepository.GetByIdAsync(request.ClientId);
            if (client == null)
                throw new InvalidOperationException($"El cliente con ID {request.ClientId} no existe");

            var order = _mapper.Map<Order>(request);
            order.OrderDate = DateTime.UtcNow;
            order.OrderState = "Pendiente";
            order.CreationUser = creationUser;
            order.CreationDate = DateTime.UtcNow;

            var created = await _orderRepository.CreateAsync(order);
            return _mapper.Map<OrderResponse>(created);
        }

        public async Task UpdateAsync(int id, UpdateOrderRequest request, string modificationUser)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido con ID {id} no encontrado");

            if (order.OrderState == "Completado" || order.OrderState == "Cancelado")
                throw new InvalidOperationException("No se pueden modificar pedidos completados o cancelados");

            if (request.TotalAmount.HasValue) order.TotalAmount = request.TotalAmount.Value;
            if (request.Description != null) order.Description = request.Description;

            order.ModificationUser = modificationUser;
            order.ModificationDate = DateTime.UtcNow;

            await _orderRepository.UpdateAsync(order);
        }

        public async Task MarkAsCompletedAsync(int id, string modificationUser)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido con ID {id} no encontrado");

            if (order.OrderState == "Cancelado")
                throw new InvalidOperationException("No se puede completar un pedido cancelado");

            order.OrderState = "Completado";
            order.ModificationUser = modificationUser;
            order.ModificationDate = DateTime.UtcNow;

            await _orderRepository.UpdateAsync(order);
        }

        public async Task MarkAsCancelledAsync(int id, string modificationUser)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido con ID {id} no encontrado");

            if (order.OrderState == "Completado")
                throw new InvalidOperationException("No se puede cancelar un pedido completado");

            order.OrderState = "Cancelado";
            order.ModificationUser = modificationUser;
            order.ModificationDate = DateTime.UtcNow;

            await _orderRepository.UpdateAsync(order);
        }

        public async Task DeleteAsync(int id)
        {
            var order = await _orderRepository.GetByIdAsync(id);
            if (order == null)
                throw new KeyNotFoundException($"Pedido con ID {id} no encontrado");

            await _orderRepository.DeleteAsync(id);
        }
    }
}
