﻿using order.be.application.Models.Request;
using order.be.application.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Interfaces.Service
{
    public interface IOrderService
    {
        Task<OrderResponse> GetByIdAsync(int id);
        Task<IEnumerable<OrderResponse>> GetAllAsync();
        Task<IEnumerable<OrderResponse>> GetFilteredAsync(OrderFilterRequest filters);
        Task<OrderResponse> CreateAsync(CreateOrderRequest request, string creationUser);
        Task UpdateAsync(int id, UpdateOrderRequest request, string modificationUser);
        Task MarkAsCompletedAsync(int id, string modificationUser);
        Task MarkAsCancelledAsync(int id, string modificationUser);
        Task DeleteAsync(int id);
    }
}
