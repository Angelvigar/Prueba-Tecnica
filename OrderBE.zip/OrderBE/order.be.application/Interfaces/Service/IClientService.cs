﻿using order.be.application.Models.Request;
using order.be.application.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Interfaces.Service
{
    public interface IClientService
    {
        Task<ClientResponse> GetByIdAsync(int id);
        Task<IEnumerable<ClientResponse>> GetAllAsync();
        Task<ClientResponse> CreateAsync(CreateClientRequest request, string creationUser);
        Task UpdateAsync(int id, UpdateClientRequest request, string modificationUser);
        Task DeleteAsync(int id);
    }
}
