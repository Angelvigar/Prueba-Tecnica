﻿using order.be.application.Models.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.application.Interfaces.Repository
{
    public interface IDashboardRepository
    {
        Task<DashboardResponse> GetSummaryAsync();
    }
}
