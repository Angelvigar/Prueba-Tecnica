﻿using AutoMapper;
using order.be.application.Models.Request;
using order.be.application.Models.Response;
using order.be.domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace order.be.application.Utils.Mapping
{
    internal class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Client, ClientResponse>();
            CreateMap<CreateClientRequest, Client>();
            CreateMap<Order, OrderResponse>()
                .ForMember(dest => dest.ClientName,
                    opt => opt.MapFrom(src => src.Client != null ? $"{src.Client.FirstName} {src.Client.LastName}" : ""))
                .ForMember(dest => dest.ClientEmail,
                    opt => opt.MapFrom(src => src.Client != null ? src.Client.Email : ""));
            CreateMap<CreateOrderRequest, Order>();
        }
    }
}
