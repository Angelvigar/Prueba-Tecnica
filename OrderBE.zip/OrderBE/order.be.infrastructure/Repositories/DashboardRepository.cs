﻿using Microsoft.EntityFrameworkCore;
using order.be.application.Interfaces.Repository;
using order.be.application.Models.Response;
using order.be.infrastructure.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.infrastructure.Repositories
{
    public class DashboardRepository : IDashboardRepository
    {
        private readonly DBContext _context;
        public DashboardRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<DashboardResponse> GetSummaryAsync()
        {
            var stats = new DashboardStats(0, 0, 0, 0);
            var daily = new List<ChartData>();
            var monthly = new List<ChartData>();

            using (var command = _context.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = "sp_GetDashboardSummary";
                command.CommandType = System.Data.CommandType.StoredProcedure;
                await _context.Database.OpenConnectionAsync();

                using (var reader = await command.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                    {
                        stats = new DashboardStats(
                            reader.GetInt32(0), reader.GetInt32(1),
                            reader.GetInt32(2), reader.GetInt32(3)
                        );
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        daily.Add(new ChartData(reader.GetString(0), reader.GetInt32(1)));
                    }
                    await reader.NextResultAsync();
                    while (await reader.ReadAsync())
                    {
                        monthly.Add(new ChartData(reader.GetString(0), reader.GetInt32(1)));
                    }
                }
            }
            return new DashboardResponse(stats, daily, monthly);
        }

    }
}