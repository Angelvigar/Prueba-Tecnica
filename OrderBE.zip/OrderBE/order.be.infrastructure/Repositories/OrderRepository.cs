﻿using Microsoft.EntityFrameworkCore;
using order.be.application.Interfaces.Repository;
using order.be.domain.Entity;
using order.be.infrastructure.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order.be.infrastructure.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private readonly DBContext _context;

        public OrderRepository(DBContext context)
        {
            _context = context;
        }

        public async Task<Order?> GetByIdAsync(int id)
        {
            return await _context.Orders
                .Include(o => o.Client)
                .FirstOrDefaultAsync(o => o.Id == id && o.Status);
        }

        public async Task<IEnumerable<Order>> GetAllAsync()
        {
            return await _context.Orders
                .Include(o => o.Client)
                .Where(o => o.Status)
                .OrderByDescending(o => o.OrderDate)
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetFilteredAsync(string? state, DateTime? date, int? clientId)
        {
            var query = _context.Orders
                .Include(o => o.Client)
                .Where(o => o.Status);

            if (!string.IsNullOrEmpty(state))
                query = query.Where(o => o.OrderState == state);

            if (date.HasValue)
                query = query.Where(o => o.OrderDate.Date == date.Value.Date);

            if (clientId.HasValue)
                query = query.Where(o => o.ClientId == clientId.Value);

            return await query.OrderByDescending(o => o.OrderDate).ToListAsync();
        }

        public async Task<Order> CreateAsync(Order order)
        {
            await _context.Orders.AddAsync(order);
            await _context.SaveChangesAsync();
            await _context.Entry(order).Reference(o => o.Client).LoadAsync();
            return order;
        }

        public async Task UpdateAsync(Order order)
        {
            _context.Entry(order).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task UpdateStatusAsync(Order order)
        {
            order.Status = false;

            _context.Entry(order).State = EntityState.Modified;

            await _context.SaveChangesAsync();
        }

    }
}
