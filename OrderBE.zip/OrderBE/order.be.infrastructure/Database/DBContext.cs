﻿using Microsoft.EntityFrameworkCore;
using order.be.domain.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace order.be.infrastructure.Database
{
    public class DBContext : DbContext
    {
        public DBContext(DbContextOptions<DBContext> options) : base(options) { }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>(entity =>
            {
                entity.ToTable("Clients");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).UseIdentityColumn();

                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Phone).HasMaxLength(20);

                entity.HasIndex(e => e.Email).IsUnique();

                entity.Property(e => e.Status).IsRequired().HasDefaultValue(true);
                entity.Property(e => e.CreationUser).IsRequired().HasMaxLength(50).HasDefaultValue("SYSTEM");
                entity.Property(e => e.CreationDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.ModificationUser).HasMaxLength(50);
                entity.Property(e => e.ModificationDate);
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.ToTable("Orders");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).UseIdentityColumn();

                entity.Property(e => e.ClientId).IsRequired();
                entity.Property(e => e.OrderDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.OrderState).IsRequired().HasMaxLength(50).HasDefaultValue("Pendiente");
                entity.Property(e => e.TotalAmount).IsRequired().HasColumnType("decimal(18,2)");
                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.Status).IsRequired().HasDefaultValue(true);
                entity.Property(e => e.CreationUser).IsRequired().HasMaxLength(50).HasDefaultValue("SYSTEM");
                entity.Property(e => e.CreationDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.ModificationUser).HasMaxLength(50);
                entity.Property(e => e.ModificationDate);

                entity.HasOne(o => o.Client)
                    .WithMany()
                    .HasForeignKey(o => o.ClientId)
                    .OnDelete(DeleteBehavior.Restrict)
                    .HasConstraintName("FK_Orders_Clients");

                entity.HasIndex(e => e.ClientId);
                entity.HasIndex(e => e.OrderState);
                entity.HasIndex(e => e.OrderDate);
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
