﻿using System.ComponentModel.DataAnnotations;

namespace auth.be.application.Models.Request
{
    public class LoginRequest
    {
        [Required(ErrorMessage = "Username es obligatorio")]
        public string Username { get; set; } 

        [Required(ErrorMessage = "Password es obligatorio")]
        public string Password { get; set; } 
    }
}