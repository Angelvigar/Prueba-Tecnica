﻿using System.ComponentModel.DataAnnotations;

namespace auth.be.application.Models.Request
{
    public class RegisterRequest
    {
        [Required(ErrorMessage = "Username es obligatorio")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username debe tener entre 3 y 50 caracteres")]
        public string Username { get; set; } 

        [Required(ErrorMessage = "Email es obligatorio")]
        [EmailAddress(ErrorMessage = "Email no es válido")]
        [StringLength(100)]
        public string Email { get; set; } 

        [Required(ErrorMessage = "Password es obligatorio")]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password debe tener al menos 6 caracteres")]
        public string Password { get; set; } 

        [Required(ErrorMessage = "RoleId es obligatorio")]
        [Range(1, 3, ErrorMessage = "RoleId debe ser 1 (Admin), 2 (Gestor) o 3 (Consultor)")]
        public int RoleId { get; set; }
    }
}