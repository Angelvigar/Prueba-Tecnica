﻿using auth.be.application.Interfaces.Authentication;
using auth.be.application.Interfaces.Repository;
using auth.be.application.Interfaces.Service;
using auth.be.application.Models.Request;
using auth.be.domain.Entity;

namespace auth.be.application.Services
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IJwtTokenGenerator _jwtTokenGenerator;

        public AuthService(IUserRepository userRepository, IPasswordHasher passwordHasher, IJwtTokenGenerator jwtTokenGenerator)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
            _jwtTokenGenerator = jwtTokenGenerator;
        }

        public async Task RegisterAsync(RegisterRequest request, string adminUsername)
        {
            var rol = await _userRepository.GetRoleByIdAsync(request.RoleId);
            if (rol == null)
            {
                throw new InvalidOperationException("El rol seleccionado no existe o no está activo");
            }

            if (await _userRepository.ExistsByUsernameAsync(request.Username))
            {
                throw new InvalidOperationException("El username ya está registrado");
            }

            if (await _userRepository.ExistsByEmailAsync(request.Email))
            {
                throw new InvalidOperationException("El email ya está registrado");
            }

            var user = new User
            {
                Username = request.Username,
                Email = request.Email,
                PasswordHash = _passwordHasher.Hash(request.Password),
                CreationUser = adminUsername,  
                CreationDate = DateTime.UtcNow
            };

            await _userRepository.CreateUserAsync(user);

            var userRole = new UserRole
            {
                UserId = user.Id,
                RoleId = rol.Id,
                CreationUser = adminUsername,  
                CreationDate = DateTime.UtcNow
            };

            await _userRepository.AddUserRoleAsync(userRole);
        }

        public async Task<string> LoginAsync(LoginRequest request)
        {
            var user = await _userRepository.GetByUsernameAsync(request.Username);

            if (user == null || !_passwordHasher.Verify(request.Password, user.PasswordHash))
            {
                throw new UnauthorizedAccessException("Credenciales inválidas");
            }

            var roles = await _userRepository.GetRolesByUserIdAsync(user.Id);
            return _jwtTokenGenerator.GenerateToken(user, roles);
        }
    }
}