﻿using auth.be.domain.Entity;

namespace auth.be.application.Interfaces.Repository
{
    public interface IUserRepository
    {
        Task<User?> GetByUsernameAsync(string username);
        Task<bool> ExistsByEmailAsync(string email);
        Task<bool> ExistsByUsernameAsync(string username);
        Task CreateUserAsync(User user);
        Task AddUserRoleAsync(UserRole userRole);
        Task<Role?> GetRoleByIdAsync(int roleId);                
        Task<List<Role>> GetRolesByUserIdAsync(int userId);
    }
}