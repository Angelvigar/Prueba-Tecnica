﻿using auth.be.application.Models.Request;

namespace auth.be.application.Interfaces.Service
{
    public interface IAuthService
    {
        Task RegisterAsync(RegisterRequest request, string adminUsername);
        Task<string> LoginAsync(LoginRequest request);
    }
}