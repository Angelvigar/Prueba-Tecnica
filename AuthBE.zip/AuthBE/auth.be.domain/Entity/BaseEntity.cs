﻿namespace auth.be.domain.Entity
{
    public abstract class BaseEntity
    {
        public bool Status { get; set; } = true;
        public string CreationUser { get; set; } = "SYSTEM";
        public DateTime CreationDate { get; set; } = DateTime.UtcNow;
        public string? ModificationUser { get; set; }
        public DateTime? ModificationDate { get; set; }
    }

    public abstract class BaseEntityWithId : BaseEntity
    {
        public int Id { get; set; }
    }
}