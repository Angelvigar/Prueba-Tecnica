﻿namespace auth.be.domain.Entity
{
    public class User : BaseEntityWithId
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
    }
}