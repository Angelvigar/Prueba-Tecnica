﻿namespace auth.be.domain.Entity
{
    public class Role : BaseEntityWithId
    {
        public string Name { get; set; }
        public string? Description { get; set; }
    }
}