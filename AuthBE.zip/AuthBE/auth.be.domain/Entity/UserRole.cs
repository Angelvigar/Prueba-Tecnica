﻿namespace auth.be.domain.Entity
{
    /// <summary>
    /// Tabla intermedia Users-Roles.
    /// No tiene Id propio: la PK es compuesta (UserId, RoleId).
    /// Hereda solo BaseEntity (auditoría sin Id).
    /// </summary>
    public class UserRole : BaseEntity
    {
        public int UserId { get; set; }
        public virtual User? User { get; set; }

        public int RoleId { get; set; }
        public virtual Role? Role { get; set; }
    }
}