﻿//using auth.be.infrastructure.Database;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.DependencyInjection;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace auth.be.infrastructure.IOC
//{
//    public static class DependecyInjection
//    {
//        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
//        {
//            // 1. CONFIGURACIÓN DE BASE DE DATOS
//            // Recuperamos la cadena "DefaultConnection" del appsettings.json
//            var connectionString = configuration.GetConnectionString("DefaultConnection");

//            services.AddDbContext<DBContext>(options =>
//            {
//                options.UseSqlServer(connectionString);

//                // MANTENIDO DE TU GUÍA: Excelente para catálogos.
//                // Evita que Entity Framework guarde caché de los datos leídos, 
//                // haciendo las lecturas mucho más rápidas y consumiendo menos RAM.
//                options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
//            });

//            // 2. INYECCIÓN DE REPOSITORIOS
//            // Aquí irás agregando cada repositorio nuevo que crees.
//            // Sintaxis: services.AddScoped<INTERFAZ, IMPLEMENTACIÓN>();

//            //services.AddScoped<ICategoriaRepository, CategoriaRepository>();

//            return services;
//        }

//    }
//}

using auth.be.application.Interfaces.Authentication;
using auth.be.application.Interfaces.Repository;
using auth.be.infrastructure.Authentication;
using auth.be.infrastructure.Database;
using auth.be.infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace auth.be.infrastructure.IOC
{

    public static class DependecyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("AuthConnection")
                ?? throw new InvalidOperationException("Connection string 'AuthConnection' no encontrada");

            services.AddDbContext<DBContext>(options =>
            {
                options.UseSqlServer(connectionString);

                options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            });

            services.AddScoped<IUserRepository, UserRepository>();

            services.AddScoped<IPasswordHasher, PasswordHasher>();
            services.AddScoped<IJwtTokenGenerator, JwtTokenGenerator>();

            return services;
        }
    }
}