﻿using auth.be.application.Interfaces.Authentication;
using auth.be.application.Interfaces.Repository;
using auth.be.infrastructure.Authentication;
using auth.be.infrastructure.Database;
using auth.be.infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace auth.be.infrastructure.IOC
{

    public static class DependecyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("AuthConnection")
                ?? throw new InvalidOperationException("Connection string 'AuthConnection' no encontrada");

            services.AddDbContext<DBContext>(options =>
            {
                options.UseSqlServer(connectionString);

                options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            });

            services.AddScoped<IUserRepository, UserRepository>();

            services.AddScoped<IPasswordHasher, PasswordHasher>();
            services.AddScoped<IJwtTokenGenerator, JwtTokenGenerator>();

            return services;
        }
    }
}