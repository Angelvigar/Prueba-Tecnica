﻿using auth.be.domain.Entity;
using Microsoft.EntityFrameworkCore;

namespace auth.be.infrastructure.Database
{
    public class DBContext : DbContext
    {
        public DBContext(DbContextOptions<DBContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).UseIdentityColumn();

                entity.Property(e => e.Username).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.PasswordHash).IsRequired(); 

                entity.HasIndex(e => e.Username).IsUnique();
                entity.HasIndex(e => e.Email).IsUnique();

                entity.Property(e => e.Status).IsRequired().HasDefaultValue(true);
                entity.Property(e => e.CreationUser).IsRequired().HasMaxLength(50).HasDefaultValue("SYSTEM");
                entity.Property(e => e.CreationDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.ModificationUser).HasMaxLength(50);
                entity.Property(e => e.ModificationDate);
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.ToTable("Roles");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).UseIdentityColumn();

                entity.Property(e => e.Name).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Description).HasMaxLength(255);

                entity.HasIndex(e => e.Name).IsUnique();

                entity.Property(e => e.Status).IsRequired().HasDefaultValue(true);
                entity.Property(e => e.CreationUser).IsRequired().HasMaxLength(50).HasDefaultValue("SYSTEM");
                entity.Property(e => e.CreationDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.ModificationUser).HasMaxLength(50);
                entity.Property(e => e.ModificationDate);

                entity.HasData(
                    new Role
                    {
                        Id = 1,
                        Name = "Admin",
                        Description = "Acceso total al sistema: gestión de usuarios, clientes, pedidos y estadísticas.",
                        Status = true,
                        CreationUser = "SYSTEM",
                        CreationDate = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                    },
                    new Role
                    {
                        Id = 2,
                        Name = "Gestor",
                        Description = "Puede gestionar clientes y pedidos, pero no tiene acceso a la administración de usuarios.",
                        Status = true,
                        CreationUser = "SYSTEM",
                        CreationDate = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                    },
                    new Role
                    {
                        Id = 3,
                        Name = "Consultor",
                        Description = "Acceso de solo lectura para visualizar el listado de clientes, pedidos y el dashboard.",
                        Status = true,
                        CreationUser = "SYSTEM",
                        CreationDate = new DateTime(2025, 1, 1, 0, 0, 0, DateTimeKind.Utc)
                    }
                );
            });

            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.ToTable("UserRoles");

                entity.HasKey(ur => new { ur.UserId, ur.RoleId })
                    .HasName("PK_UserRoles");

                entity.Property(ur => ur.UserId).IsRequired();
                entity.Property(ur => ur.RoleId).IsRequired();

                entity.Property(e => e.Status).IsRequired().HasDefaultValue(true);
                entity.Property(e => e.CreationUser).IsRequired().HasMaxLength(50).HasDefaultValue("SYSTEM");
                entity.Property(e => e.CreationDate).IsRequired().HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.ModificationUser).HasMaxLength(50);
                entity.Property(e => e.ModificationDate);

                entity.HasOne(ur => ur.User)
                    .WithMany()
                    .HasForeignKey(ur => ur.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_UserRoles_Users");

                entity.HasOne(ur => ur.Role)
                    .WithMany()
                    .HasForeignKey(ur => ur.RoleId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_UserRoles_Roles");
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}