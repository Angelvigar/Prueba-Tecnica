﻿using auth.be.application.Interfaces.Service;
using auth.be.application.Models.Request;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace auth.be.api.Controllers.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize] 
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(IAuthService authService, ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("register")]
        [Authorize(Roles = "Admin")] 
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(new { errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage)) });
                }

                var adminUsername = User.Identity?.Name ?? User.FindFirst("username")?.Value ?? "ADMIN";

                await _authService.RegisterAsync(request, adminUsername);

                _logger.LogInformation("Admin {AdminUsername} registró al usuario {Username} con rol {RoleId}",
                    adminUsername, request.Username, request.RoleId);

                return Ok(new { message = "Usuario registrado exitosamente" });
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning("Intento de registro fallido: {Message}", ex.Message);
                return BadRequest(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error inesperado al registrar usuario");
                return StatusCode(500, new { error = "Error al registrar el usuario" });
            }
        }

        [HttpPost("login")]
        [AllowAnonymous] 
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(new { errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage)) });
                }

                var token = await _authService.LoginAsync(request);

                _logger.LogInformation("Usuario {Username} inició sesión exitosamente", request.Username);

                return Ok(new { token });
            }
            catch (UnauthorizedAccessException ex)
            {
                _logger.LogWarning("Intento de login fallido para usuario {Username}", request.Username);
                return Unauthorized(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error inesperado en login");
                return StatusCode(500, new { error = "Error interno del servidor" });
            }
        }

        [HttpGet("generar-hash-prueba")]
        [AllowAnonymous] 
        public IActionResult GenerarHash(string password)
        {
            var hash = BCrypt.Net.BCrypt.HashPassword(password);
            return Ok(new { Password = password, HashGenerado = hash });
        }
    }
}